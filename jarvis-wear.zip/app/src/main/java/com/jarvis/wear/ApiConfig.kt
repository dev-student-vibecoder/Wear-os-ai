package com.jarvis.wear

/** Private sideload configuration. Replace the placeholder before building. */
object ApiConfig {
    const val GEMINI_API_KEY = "PASTE_YOUR_GEMINI_API_KEY_HERE"
}
