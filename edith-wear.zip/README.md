# EDITH Wear OS

EDITH is a personal, sideloaded Wear OS assistant for a round Galaxy Watch 4 Classic. It uses a single fixed screen designed around the circular safe area.

## Interaction model

- **Tap the question field** to open the watch keyboard. The IME Send action and the visible Send button both submit the question.
- **Voice** starts speech recognition and speaks the response when recognition succeeds.
- **Live On** is an explicit mode. It requests Gemini Google Search grounding, and EDITH only labels an answer LIVE when the returned response contains grounding metadata.
- **Timer**, **Alarm**, and **open-app** requests are still handled if you type or speak them (e.g. "set a timer for 10 minutes"); the dedicated shortcut buttons for these were removed to give the reply panel more room.

The reply panel scrolls. It fills the remaining vertical space between the input row and the bottom button row, so long answers scroll instead of being clipped.

## Live search and quota

gemini-2.5-flash-lite with google_search on the Gemini v1beta generateContent endpoint is a supported API combination. A 429 is a quota/rate-limit response, not evidence that the JSON request is malformed.

If Gemini returns 429 for a live request, EDITH shows an honest **Live unavailable** message and **does not retry without search**. Therefore it never presents a normal model response as fresh web information. A live answer is possible only while the key's project has Gemini/Google Search quota.

## API key

Put a personal Gemini API key in app/src/main/java/com/edith/wear/ApiConfig.kt before building. The key is compiled into the APK and can be extracted by anyone who has the APK. This is acceptable only for a private build that you do not share.

## Build locally

This project includes the Gradle 8.13 wrapper and uses Android Gradle Plugin 8.13.0. Build with **JDK 17** and an installed Android SDK Platform 34.

~~~
set JAVA_HOME=C:\path\to\jdk-17
set ANDROID_HOME=C:\Users\YOUR_NAME\AppData\Local\Android\Sdk
gradlew.bat :app:assembleDebug
~~~

The debug APK path is app/build/outputs/apk/debug/app-debug.apk.

## Test checklist

Before calling a build ready, test on a Galaxy Watch 4 Classic or matching round emulator:

1. Tap the text field and confirm the Wear OS keyboard opens; type text and use both keyboard Send and the on-screen Send button.
2. Toggle Live On, ask a time-sensitive question, and confirm the result reads LIVE; deliberately test the 429 path if your quota is exhausted.
3. Grant mic permission, use Voice, and confirm speech recognition plus spoken reply.
4. Try Timer, Alarm, and Apps; available handlers vary with the watch's installed apps.
5. Install with adb install -r app/build/outputs/apk/debug/app-debug.apk.

## Verification status

The source has been statically checked for XML IDs, string resources, manifest declarations, and Kotlin references. It has **not** been built or installed in this environment: Gradle cannot establish the required local loopback connection here, and no Wear OS emulator/watch is attached. No APK is included until a real build succeeds.
