package com.friday.wear

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.util.Locale

object OrbitCommands {
    sealed class Result {
        data class Done(val message: String) : Result()
        object NotACommand : Result()
    }

    fun run(context: Context, raw: String): Result {
        val text = raw.trim().lowercase(Locale.ROOT)

        if (text.contains("timer")) {
            val match = Regex("(\\d+)\\s*(hour|hours|minute|minutes|second|seconds)?")
                .find(text)
            val number = match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 5
            val unit = match?.groupValues?.getOrNull(2).orEmpty()
            val seconds = when {
                unit.startsWith("hour") -> number * 3600
                unit.startsWith("second") -> number
                else -> number * 60
            }
            val displayUnit = when {
                unit.startsWith("hour") -> if (number == 1) "hour" else "hours"
                unit.startsWith("second") -> if (number == 1) "second" else "seconds"
                else -> if (number == 1) "minute" else "minutes"
            }
            return launch(
                context,
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "FRIDAY timer"),
                "Opening the timer for $number $displayUnit."
            )
        }

        if (text.contains("alarm") || text.contains("wake me")) {
            val match = Regex("(?:at|for)\\s+(\\d{1,2})(?::|\\s)(\\d{2})\\s*(am|pm)?")
                .find(text)
            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            val message = if (match == null) {
                "Opening the alarm screen."
            } else {
                var hour = match.groupValues[1].toInt()
                val minute = match.groupValues[2].toInt()
                if (match.groupValues[3] == "pm" && hour < 12) hour += 12
                if (match.groupValues[3] == "am" && hour == 12) hour = 0
                if (hour !in 0..23 || minute !in 0..59) return Result.Done("Invalid alarm time.")
                intent.putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                "Opening the alarm screen for %02d:%02d.".format(hour, minute)
            }
            return launch(context, intent, message)
        }

        if (text.startsWith("open ") || text.startsWith("launch ")) {
            val target = text.substringAfter(' ').trim()
            if (target.isBlank()) return Result.Done("Say the name of an app to open.")

            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = context.packageManager.queryIntentActivities(launcherIntent, 0)
            val app = apps.firstOrNull {
                context.packageManager.getApplicationLabel(it.activityInfo.applicationInfo)
                    .toString()
                    .lowercase(Locale.ROOT) == target
            } ?: apps.firstOrNull {
                val label = context.packageManager.getApplicationLabel(it.activityInfo.applicationInfo)
                    .toString()
                    .lowercase(Locale.ROOT)
                label.contains(target) || target.contains(label)
            }
            if (app != null) {
                val launchIntent = Intent(launcherIntent).setClassName(
                    app.activityInfo.packageName,
                    app.activityInfo.name
                )
                return launch(
                    context,
                    launchIntent,
                    "Opening ${context.packageManager.getApplicationLabel(app.activityInfo.applicationInfo)}."
                )
            }
            return Result.Done("I could not find a launchable app named $target.")
        }

        return Result.NotACommand
    }

    private fun launch(context: Context, intent: Intent, message: String): Result {
        if (intent.resolveActivity(context.packageManager) == null) {
            return Result.Done("That action is not available on this watch.")
        }
        return try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result.Done(message)
        } catch (_: Exception) {
            Result.Done("That action could not be opened on this watch.")
        }
    }
}
