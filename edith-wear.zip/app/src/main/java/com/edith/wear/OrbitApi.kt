package com.edith.wear

import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object OrbitApi {
    private const val MODEL = "gemini-2.5-flash-lite"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .build()

    data class Answer(val text: String, val isLiveGrounded: Boolean)

    interface Listener {
        fun onAnswer(answer: Answer)
        fun onFailure(message: String)
    }

    fun ask(question: String, useWebSearch: Boolean, listener: Listener) {
        if (ApiConfig.GEMINI_API_KEY == "PASTE_YOUR_GEMINI_API_KEY_HERE" ||
            ApiConfig.GEMINI_API_KEY.isBlank()
        ) {
            listener.onFailure("Add your Gemini key in ApiConfig.kt, then rebuild EDITH.")
            return
        }

        val requestJson = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text",
                    "You are EDITH, a concise assistant on a round smartwatch. " +
                        "Answer in 1 to 3 short sentences. " +
                        if (useWebSearch) {
                            "Use Google Search before answering and provide only a current, " +
                                "grounded answer."
                        } else {
                            "Do not claim that information is current unless you know it is."
                        }
                )))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", question)))
            }))
            if (useWebSearch) {
                put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            }
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("Content-Type", "application/json")
            .addHeader("x-goog-api-key", ApiConfig.GEMINI_API_KEY)
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                listener.onFailure("Network error: ${e.message ?: "unknown error"}")
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.use {
                    val raw = it.body?.string().orEmpty()
                    if (!it.isSuccessful) {
                        val detail = raw.take(220).replace("\n", " ")
                        val message = when (it.code) {
                            429 -> if (useWebSearch) {
                                "Live search is unavailable because the Gemini/Google Search quota " +
                                    "is exhausted. No non-live fallback was used."
                            } else {
                                "Gemini request quota is exhausted. Try again later."
                            }
                            401, 403 -> "Gemini rejected the API key or this project is not allowed to use it."
                            else -> "Gemini error ${it.code}: $detail"
                        }
                        listener.onFailure(message)
                        return
                    }

                    try {
                        val root = JSONObject(raw)
                        val parts = root.getJSONArray("candidates")
                            .getJSONObject(0)
                            .getJSONObject("content")
                            .getJSONArray("parts")
                        val answer = buildString {
                            for (index in 0 until parts.length()) {
                                append(parts.getJSONObject(index).optString("text"))
                            }
                        }.trim()
                        if (answer.isEmpty()) {
                            listener.onFailure("Gemini returned no readable answer.")
                            return
                        }

                        val grounding = root.optJSONObject("groundingMetadata")
                        val grounded = (grounding?.optJSONArray("webSearchQueries")?.length() ?: 0) > 0 ||
                            (grounding?.optJSONArray("groundingChunks")?.length() ?: 0) > 0
                        if (useWebSearch && !grounded) {
                            listener.onFailure(
                                "Live search could not be confirmed, so EDITH did not show " +
                                    "an unverified current answer."
                            )
                            return
                        }
                        listener.onAnswer(Answer(answer, grounded))
                    } catch (_: Exception) {
                        listener.onFailure("Could not read the Gemini response.")
                    }
                }
            }
        })
    }
}
