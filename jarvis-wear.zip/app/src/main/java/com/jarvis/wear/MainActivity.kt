package com.jarvis.wear

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var response: TextView
    private lateinit var input: EditText
    private lateinit var liveButton: TextView
    private lateinit var askButton: TextView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var speakNextResponse = false
    private var liveSearchEnabled = false
    private var listening = false

    companion object {
        private const val REQUEST_MIC = 601
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.txt_status)
        response = findViewById(R.id.txt_response)
        input = findViewById(R.id.input_prompt)
        liveButton = findViewById(R.id.btn_live)
        askButton = findViewById(R.id.btn_ask)
        tts = TextToSpeech(this, this)

        askButton.setOnClickListener { submit() }
        findViewById<TextView>(R.id.btn_voice).setOnClickListener { requestVoice() }
        liveButton.setOnClickListener {
            liveSearchEnabled = !liveSearchEnabled
            updateLiveControl()
            if (liveSearchEnabled) {
                status.text = getString(R.string.status_live_ready)
                openKeyboard()
            } else {
                status.text = getString(R.string.status_ready)
            }
        }

        input.setOnClickListener { openKeyboard() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submit()
                true
            } else {
                false
            }
        }
        updateLiveControl()
    }

    private fun updateLiveControl() {
        liveButton.text = getString(
            if (liveSearchEnabled) R.string.btn_live_on else R.string.btn_live_off
        )
        liveButton.contentDescription = liveButton.text
        liveButton.setTextColor(
            ContextCompat.getColor(
                this,
                if (liveSearchEnabled) R.color.jarvis_cyan else R.color.jarvis_muted
            )
        )
    }

    private fun openKeyboard() {
        input.requestFocus()
        input.post {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
    }

    private fun submit() {
        val question = input.text.toString().trim()
        if (question.isEmpty()) {
            status.text = getString(R.string.status_enter_question)
            openKeyboard()
            return
        }

        val searchThisQuestion = liveSearchEnabled
        closeKeyboard()

        val command = OrbitCommands.run(this, question)
        if (command is OrbitCommands.Result.Done) {
            showAnswer(command.message, speakNextResponse, R.string.status_ready)
            speakNextResponse = false
            return
        }

        status.text = getString(
            if (searchThisQuestion) R.string.status_searching else R.string.status_thinking
        )
        response.text = getString(R.string.response_thinking)
        askButton.isEnabled = false

        OrbitApi.ask(question, searchThisQuestion, object : OrbitApi.Listener {
            override fun onAnswer(answer: OrbitApi.Answer) {
                runOnUiThread {
                    askButton.isEnabled = true
                    showAnswer(
                        answer.text,
                        speakNextResponse,
                        if (answer.isLiveGrounded) R.string.status_live_result
                        else R.string.status_ready
                    )
                    speakNextResponse = false
                }
            }

            override fun onFailure(message: String) {
                runOnUiThread {
                    askButton.isEnabled = true
                    status.text = getString(
                        if (searchThisQuestion) R.string.status_live_unavailable
                        else R.string.status_ready
                    )
                    response.text = message
                    speakNextResponse = false
                }
            }
        })
    }

    private fun runLocal(command: String) {
        val result = OrbitCommands.run(this, command)
        if (result is OrbitCommands.Result.Done) {
            showAnswer(result.message, false, R.string.status_ready)
        }
    }

    private fun showAnswer(text: String, speak: Boolean, statusRes: Int) {
        status.text = getString(statusRes)
        response.text = text
        if (speak) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun requestVoice() {
        if (listening) {
            recognizer?.stopListening()
            return
        }

        speakNextResponse = true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_MIC
            )
            return
        }
        startListening()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MIC && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == REQUEST_MIC) {
            speakNextResponse = false
            status.text = getString(R.string.status_mic_denied)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speakNextResponse = false
            status.text = getString(R.string.status_no_speech)
            return
        }

        recognizer?.destroy()
        recognizer = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
            ) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
        } catch (_: UnsupportedOperationException) {
            SpeechRecognizer.createSpeechRecognizer(this)
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening = true
                status.text = getString(R.string.status_listening)
            }

            override fun onBeginningOfSpeech() {
                status.text = getString(R.string.status_listening)
            }

            override fun onEndOfSpeech() {
                status.text = getString(R.string.status_processing)
            }

            override fun onResults(results: Bundle?) {
                listening = false
                val words = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (words.isEmpty()) {
                    speakNextResponse = false
                    status.text = getString(R.string.status_ready)
                } else {
                    input.setText(words)
                    submit()
                }
            }

            override fun onError(error: Int) {
                listening = false
                speakNextResponse = false
                status.text = getString(R.string.status_speech_error)
            }

            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
